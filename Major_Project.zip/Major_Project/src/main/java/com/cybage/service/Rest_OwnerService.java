package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entities.Rest_Owner;
import com.cybage.repository.Rest_OwnerRepository;

@Service
public class Rest_OwnerService {
	
	@Autowired
	Rest_OwnerRepository rest_ownerrepo;
	
	public String saveOwnerDetails(Rest_Owner rest_owner) {
		Rest_Owner ownerDetails = rest_ownerrepo.save(rest_owner);
		return ownerDetails.getName()
				+", you have successfully registerd by Email id : "
				 +ownerDetails.getEmail();
	}
	

}
