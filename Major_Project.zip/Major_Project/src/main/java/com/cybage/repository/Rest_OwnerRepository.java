package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.cybage.entities.Rest_Owner;

@Repository
@EnableJpaRepositories
public interface Rest_OwnerRepository extends JpaRepository<Rest_Owner, Integer> {
	  
	
	// String saveOwnerDetails(Rest_Owner rest_owner);
//		
//	   Rest_Owner getOwnerById(int id);
//			
//	    Rest_Owner updateownerDetails(Rest_Owner rest_owner);
//			
//	   String deleteOwnerDetails(int rest_owner_id);

}
