package com.cybage.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.dto.LoginRequest;
import com.cybage.entities.Admin;
import com.cybage.entities.Rest_Owner;
import com.cybage.service.AdminService;
import com.cybage.service.Rest_OwnerService;

@RestController
@EnableAutoConfiguration
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {
	
	@Autowired
	AdminService adminservice;
	
	@Autowired
	Rest_OwnerService rest_ownerservice;
	
	@PostMapping("/register")
	public ResponseEntity<?>saveownerDetails(@RequestBody @Valid Rest_Owner rest_owner)
	{
		System.out.println("In save Rest_owner");
		return new ResponseEntity<>(rest_ownerservice.saveOwnerDetails(rest_owner),HttpStatus.CREATED);
	}
	
	@PostMapping("/login")
	public Admin adminLogin(@RequestBody @Valid LoginRequest payload)
	{
		System.out.println("auth vendor"+payload);
		return adminservice.adminLogin(payload.getEmail(),payload.getPassword());
		
	}
	

}
